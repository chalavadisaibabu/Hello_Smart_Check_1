import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CHECKLIST, type Metadata, type ItemState } from './checklist';

function safeFile(value:string){return (value.trim()||'Site').replace(/[^a-zA-Z0-9_-]+/g,'_').slice(0,45)}
export function downloadReport(meta:Metadata, entries:Record<string,ItemState>){
  const pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4'});
  const pageWidth=210, margin=15;
  const counts={pass:0,fail:0,na:0,pending:0};
  CHECKLIST.forEach(g=>g.items.forEach((_,j)=>counts[entries[`${g.id}-${j}`]?.status||'pending']++));
  const total=Object.values(counts).reduce((a,b)=>a+b,0);
  const dark:[number,number,number]=[7,27,53];
  function header(){
    pdf.setFillColor(...dark);pdf.rect(0,0,210,27,'F');
    pdf.setTextColor(255,255,255);pdf.setFont('helvetica','bold');pdf.setFontSize(17);pdf.text('IOTIQ',margin,13);
    pdf.setFont('helvetica','normal');pdf.setFontSize(9);pdf.text('ENERGY MANAGEMENT SYSTEM',margin,20);
    pdf.setFontSize(9);pdf.text('COMMISSIONING REPORT',195,16,{align:'right'});
    pdf.setTextColor(30,45,63);
  }
  header();
  pdf.setFontSize(16);pdf.setFont('helvetica','bold');pdf.text('Energy Meter Integration Checklist',margin,38);
  pdf.setFont('helvetica','normal');pdf.setFontSize(9);
  const info=[
    ['Project',meta.project||'—','Site / Location',meta.site||'—'],
    ['Engineer',meta.engineer||'—','Customer',meta.customer||'—'],
    ['Company',meta.company||'IOTIQ','Date',meta.date||'—'],
    ['Controller ID',meta.controllerId||'—','Protocol',meta.protocol],
    ['Meters Connected',meta.meterCount||'—','Report Status',counts.fail?'ISSUES FOUND':counts.pending?'IN PROGRESS':'CHECKED']
  ];
  autoTable(pdf,{startY:44,head:[],body:info,theme:'plain',margin:{left:margin,right:margin},styles:{fontSize:8.5,cellPadding:2.5},columnStyles:{0:{fontStyle:'bold',cellWidth:28},1:{cellWidth:58},2:{fontStyle:'bold',cellWidth:32},3:{cellWidth:62}}});
  let y=(pdf as any).lastAutoTable.finalY+7;
  pdf.setFont('helvetica','bold');pdf.setFontSize(10);pdf.text(`RESULT SUMMARY    ${counts.pass} PASS    |    ${counts.fail} FAIL    |    ${counts.na} N/A    |    ${counts.pending} PENDING    |    ${total} TOTAL`,margin,y);
  y+=6;
  pdf.setFont('helvetica','normal');pdf.setFontSize(8);pdf.text(`Inspection coverage: ${Math.round((total-counts.pending)/total*100)}% completed`,margin,y);
  y+=6;
  for(let index=0;index<CHECKLIST.length;index++){
    const group=CHECKLIST[index];
    const rows=group.items.map((item,j)=>{
      const e=entries[`${group.id}-${j}`]||{status:'pending',remarks:''};
      return [String(j+1).padStart(2,'0'),item,e.status==='na'?'N/A':e.status.toUpperCase(),e.remarks||'—'];
    });
    if(y > 253){pdf.addPage();y=38;}
    pdf.setFont('helvetica','bold');pdf.setFontSize(10);pdf.setTextColor(23,57,96);
    pdf.text(`${index+1}. ${group.title}`,margin,y);y+=5;
    autoTable(pdf,{
      startY:y,head:[['#','Checkpoint','Result','Engineer Remarks']],body:rows,
      theme:'grid',showHead:'everyPage',margin:{left:margin,right:margin,top:35,bottom:19},
      styles:{fontSize:8,cellPadding:2.6,overflow:'linebreak',valign:'top',lineColor:[218,225,232],lineWidth:0.15},
      headStyles:{fillColor:dark,textColor:255,fontSize:8,fontStyle:'bold'},
      alternateRowStyles:{fillColor:[248,250,252]},
      columnStyles:{0:{cellWidth:9,halign:'center'},1:{cellWidth:93},2:{cellWidth:21,halign:'center'},3:{cellWidth:57}},
      willDrawCell:(data)=>{
        if(data.section==='body'&&data.column.index===2){
          const raw=String(data.cell.raw||'');
          if(raw==='PASS')data.cell.styles.textColor=[12,130,88];
          if(raw==='FAIL')data.cell.styles.textColor=[190,45,45];
          if(raw==='PENDING')data.cell.styles.textColor=[151,104,24];
        }
      }
    });
    y=(pdf as any).lastAutoTable.finalY+11;
  }
  if(meta.notes.trim()){
    if(y>250){pdf.addPage();y=37;}
    pdf.setFontSize(10);pdf.setFont('helvetica','bold');pdf.text('COMMISSIONING NOTES',margin,y);
    y+=6;pdf.setFontSize(9);pdf.setFont('helvetica','normal');
    const lines=pdf.splitTextToSize(meta.notes,180);
    for(const line of lines){if(y>272){pdf.addPage();y=37;}pdf.text(line,margin,y);y+=5;}
  }
  if(y>252){pdf.addPage();y=39;}
  pdf.setDrawColor(160,170,184);pdf.line(15,y+14,88,y+14);pdf.line(122,y+14,195,y+14);
  pdf.setFontSize(8);pdf.setTextColor(80,91,107);pdf.text('Commissioning Engineer / Date',15,y+19);pdf.text('Customer / Authorized Sign-off',122,y+19);
  const numPages=pdf.getNumberOfPages();
  for(let i=1;i<=numPages;i++){
    pdf.setPage(i);
    if(i>1)header();
    pdf.setFontSize(8);pdf.setTextColor(115,125,140);
    pdf.text(`Generated: ${new Date().toLocaleString('en-IN')}  |  IOTIQ EMS`,15,289);
    pdf.text(`Page ${i} of ${numPages}`,195,289,{align:'right'});
  }
  pdf.save(`IOTIQ_EMS_${safeFile(meta.site)}_${meta.date||'Commissioning'}.pdf`);
}
