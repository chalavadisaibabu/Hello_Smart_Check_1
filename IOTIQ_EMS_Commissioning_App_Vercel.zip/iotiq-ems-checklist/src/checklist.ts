export const CHECKLIST = [
  { id:'compat', title:'Energy Meter Compatibility', subtitle:'Confirm devices, technical documents and required measurement points', items:[
    'Record energy meter manufacturer and model number',
    'Confirm Modbus RTU (RS485) and/or Modbus TCP (Ethernet) support',
    'Obtain and verify the manufacturer Modbus register map',
    'Identify mandatory parameters: voltage, current, kW, kWh, PF and frequency',
    'Verify supported register data types and register lengths',
    'Check CT/PT ratios and engineering-unit scaling factors',
    'Confirm bus loading, addressing range and device communication requirements'
  ]},
  { id:'wiring', title:'Physical Connections & Wiring', subtitle:'Inspect the controller, communication cables and installation safety', items:[
    'Verify IOTIQ Controller power supply and normal startup',
    'Verify RS485 A/B polarity against each device manual',
    'Confirm RS485 meters use daisy-chain (bus) wiring, not star wiring',
    'Verify RS485 end termination and biasing where required',
    'Verify communication cable shield and reference/grounding arrangement',
    'Inspect Ethernet patch cables and network switch connections',
    'Confirm meter electrical supply and CT/PT wiring checked by qualified personnel',
    'Verify galvanic isolation and separation of communication and power wiring'
  ]},
  { id:'communication', title:'Communication Configuration', subtitle:'Validate serial settings, IP setup, polling and addressing', items:[
    'Assign unique slave IDs for meters on each RS485 bus',
    'Verify serial baud rate, parity, data bits and stop bits',
    'Configure static or reserved IP addresses for Modbus TCP meters',
    'Verify Modbus TCP port (typically 502) and Unit ID',
    'Confirm the IOTIQ Controller establishes communication with each meter',
    'Configure communication timeouts and retry counts',
    'Configure polling interval appropriate for meter count and register load'
  ]},
  { id:'acquisition', title:'Meter Data Acquisition', subtitle:'Confirm field readings and Modbus register decoding', items:[
    'Read voltage values (phase-neutral and phase-phase where supported)',
    'Read phase-wise and total current values',
    'Read active power (kW) and verify its direction/sign',
    'Read cumulative active energy (kWh)',
    'Read power factor and frequency',
    'Read reactive power (kVAR) and apparent power (kVA), where available',
    'Verify function code, zero-based register offset and register count',
    'Validate scaling, units, signedness, byte order and word order',
    'Verify handling of unsupported registers, exceptions and invalid values'
  ]},
  { id:'ems', title:'EMS Application Integration', subtitle:'Check telemetry, visibility, reporting and offline operation', items:[
    'Map controller device IDs to the correct meter and site',
    'Verify MQTT or HTTPS telemetry delivery to the EMS platform',
    'Compare live dashboard readings against the source meter',
    'Verify timestamps, timezone and historical data retention',
    'Check individual meter views and overall summary dashboard',
    'Verify energy consumption trends and downloadable reports',
    'Configure and test alert thresholds and notifications',
    'Test local buffering and synchronization after cloud/network outage'
  ]},
  { id:'reliability', title:'Performance & Reliability Testing', subtitle:'Validate scale, recovery and stable long-running performance', items:[
    'Complete communication test with one energy meter',
    'Complete communication test with five energy meters',
    'Verify full RS485 segment capacity at the target polling interval',
    'Test parallel Modbus RTU and Modbus TCP operation when applicable',
    'Confirm each configured meter updates within the required interval',
    'Disconnect/reconnect a meter and confirm failure alarm and recovery',
    'Power-cycle the IOTIQ Controller and confirm automatic restart/recovery',
    'Complete long-duration test and review communication error counters'
  ]},
  { id:'handover', title:'Commissioning & Handover', subtitle:'Document the final installation and obtain sign-off', items:[
    'Record all meter manufacturers, models and serial numbers',
    'Record meter locations, Modbus IDs, bus/port or IP addresses',
    'Archive approved communication settings and Modbus register maps',
    'Verify installation against the approved as-built wiring diagram',
    'Attach or reference meter-by-meter measurement verification results',
    'Demonstrate EMS dashboard functionality to the customer',
    'Record open issues, corrective actions and responsible persons',
    'Obtain commissioning sign-off from site engineer or customer'
  ]}
] as const;
export type Status = 'pending' | 'pass' | 'fail' | 'na';
export type ItemState = {status:Status; remarks:string};
export type Metadata = {project:string;site:string;engineer:string;company:string;date:string;protocol:string;controllerId:string;meterCount:string;customer:string;notes:string};
export type SavedReport = {meta:Metadata;entries:Record<string,ItemState>;savedAt:string};
export const STORAGE_KEY='iotiq_ems_commissioning_v1';
