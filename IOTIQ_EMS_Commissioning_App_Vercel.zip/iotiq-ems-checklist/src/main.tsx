import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, AlertTriangle, ArrowDownToLine, Check, CheckCircle2, ChevronDown, ChevronRight, ClipboardCheck, Cloud, Cpu, FileText, HardDriveDownload, Info, LayoutDashboard, RotateCcw, Save, Search, ShieldCheck, XCircle } from 'lucide-react';
import { CHECKLIST, STORAGE_KEY, type ItemState, type Metadata, type SavedReport, type Status } from './checklist';
import { downloadReport } from './pdf';
import './style.css';

const today = () => new Date().toLocaleDateString('en-CA');
const initialMeta:Metadata={project:'',site:'',engineer:'',company:'IOTIQ',date:today(),protocol:'Both RTU & TCP',controllerId:'',meterCount:'',customer:'',notes:''};
const initialData=():SavedReport=>{
  try{const value=localStorage.getItem(STORAGE_KEY); if(value){const saved=JSON.parse(value);return {meta:{...initialMeta,...saved.meta},entries:saved.entries||{},savedAt:saved.savedAt||''};}}catch{/* ignore invalid file */}
  return {meta:initialMeta,entries:{},savedAt:''};
};
const sections=CHECKLIST.map(g=>({...g,items:[...g.items]}));
const total=sections.reduce((s,g)=>s+g.items.length,0);
const statusLabels:Record<Status,string>={pending:'Pending',pass:'Pass',fail:'Fail',na:'N/A'};
const safeFile = (s:string)=>s.replace(/[^\w-]+/g,'_').slice(0,40);
function App(){
 const [savedInitial] =useState(initialData);
 const [meta,setMeta]=useState<Metadata>(savedInitial.meta);
 const [entries,setEntries]=useState<Record<string,ItemState>>(savedInitial.entries);
 const [expanded,setExpanded]=useState<Record<string,boolean>>({compat:true});
 const [search,setSearch]=useState('');
 const [filter,setFilter]=useState<'all'|Status>('all');
 const [view,setView]=useState<'checklist'|'overview'>('checklist');
 const [notice,setNotice]=useState('');
 const [confirmReset,setConfirmReset]=useState(false);
 const counts=useMemo(()=>{
  const c={pass:0,fail:0,na:0,pending:0};
  sections.forEach(g=>g.items.forEach((_,i)=>c[entries[`${g.id}-${i}`]?.status||'pending']++));return c;
 },[entries]);
 const completed=total-counts.pending, progress=Math.round(completed/total*100);
 useEffect(()=>{
  const stamp=new Date().toISOString();
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify({meta,entries,savedAt:stamp}));}catch{/* storage might be disabled */}
 },[meta,entries]);
 useEffect(()=>{if(notice){const t=setTimeout(()=>setNotice(''),3200);return ()=>clearTimeout(t)}},[notice]);
 const updateMeta=(key:keyof Metadata,value:string)=>setMeta(prev=>({...prev,[key]:value}));
 const updateEntry=(key:string,patch:Partial<ItemState>)=>setEntries(prev=>({...prev,[key]:{status:'pending',remarks:'',...prev[key],...patch}}));
 const allExpanded=()=>setExpanded(Object.fromEntries(sections.map(g=>[g.id,true])));
 const exportJson=()=>{
  const blob=new Blob([JSON.stringify({meta,entries,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`IOTIQ_EMS_${safeFile(meta.site||'Checklist')}.json`;a.click();URL.revokeObjectURL(url);setNotice('Backup exported.');
 };
 const importJson=async(e:React.ChangeEvent<HTMLInputElement>)=>{
  const file=e.target.files?.[0];if(!file)return;
  try{
    const data=JSON.parse(await file.text());if(!data.meta||typeof data.entries!=='object'||!data.entries)throw new Error('Invalid format');
    setMeta({...initialMeta,...data.meta});setEntries(data.entries);setNotice('Checklist backup imported.');
  }catch{setNotice('Could not import this file. Use a checklist JSON backup.')}e.target.value='';
 };
 const reset=()=>{setMeta({...initialMeta});setEntries({});setExpanded({compat:true});setConfirmReset(false);setNotice('New blank checklist created.');};
 return <div className="app-shell">
  <aside className="sidebar">
   <div className="brand"><div className="brand-mark"><Activity size={23} strokeWidth={2.6}/></div><div><strong>IOTIQ</strong><span>ENGINEERING PORTAL</span></div></div>
   <div className="workspace-caption">WORKSPACE</div>
   <button className={`nav-item ${view==='checklist'?'active':''}`} onClick={()=>setView('checklist')}><ClipboardCheck size={18}/> Commissioning Checklist <ChevronRight size={15} className="nav-right"/></button>
   <button className={`nav-item ${view==='overview'?'active':''}`} onClick={()=>setView('overview')}><LayoutDashboard size={18}/> Overview <ChevronRight size={15} className="nav-right"/></button>
   <div className="sidebar-bottom"><div className="sidebar-info"><ShieldCheck size={20}/><div><strong>Site-ready workflows</strong><span>Field verification & reporting</span></div></div><div className="local-badge"><span className="dot"/> Locally saved on this device</div></div>
  </aside>
  <main className="main">
   <div className="topbar"><div className="breadcrumb">Operations <ChevronRight size={13}/> <strong>EMS Commissioning</strong></div><div className="topbar-right"><span className="draft-tag"><span className="dot"/> Auto-saved locally</span><span className="avatar">{meta.engineer?.trim()?.[0]?.toUpperCase()||'E'}</span></div></div>
   <div className="page">
    <div className="page-heading"><div><div className="eyebrow"><Cpu size={14}/> IOTIQ EMS GATEWAY</div><h1>Energy Meter Commissioning</h1><p>Validate, document and certify every step of your meter integration.</p></div><button className="btn btn-primary export-top" onClick={()=>downloadReport(meta,entries)}><ArrowDownToLine size={17}/> Download PDF Report</button></div>
    <div className="stats">
      <Stat label="Total checkpoints" count={total} icon={<ClipboardCheck size={19}/>} accent="blue"/>
      <Stat label="Passed" count={counts.pass} icon={<CheckCircle2 size={19}/>} accent="green"/>
      <Stat label="Failed" count={counts.fail} icon={<XCircle size={19}/>} accent="red"/>
      <Stat label="Pending" count={counts.pending} icon={<Activity size={19}/>} accent="orange"/>
    </div>
    <section className="panel project-panel"><div className="panel-head"><div className="head-icon"><FileText size={19}/></div><div><h2>Project information</h2><p>Details included in the commissioning PDF</p></div><div className="panel-spacer"/><span className="section-pill">PROJECT DETAILS</span></div>
      <div className="fields">
       <Field label="Project name" value={meta.project} onChange={v=>updateMeta('project',v)} placeholder="e.g. SmartCheck EMS Integration"/>
       <Field label="Site / Location" value={meta.site} onChange={v=>updateMeta('site',v)} placeholder="e.g. Hyderabad – Building A"/>
       <Field label="Engineer name" value={meta.engineer} onChange={v=>updateMeta('engineer',v)} placeholder="Commissioning engineer"/>
       <Field label="Customer / Client" value={meta.customer} onChange={v=>updateMeta('customer',v)} placeholder="Customer organization"/>
       <Field label="IOTIQ controller ID" value={meta.controllerId} onChange={v=>updateMeta('controllerId',v)} placeholder="e.g. IOTIQ-EMS-001"/>
       <Field label="Number of meters" value={meta.meterCount} onChange={v=>updateMeta('meterCount',v)} placeholder="e.g. 25" type="number"/>
       <div className="field"><label>Communication protocol</label><select value={meta.protocol} onChange={e=>updateMeta('protocol',e.target.value)}><option>Both RTU & TCP</option><option>Modbus RTU (RS485)</option><option>Modbus TCP (Ethernet)</option></select></div>
       <Field label="Inspection date" value={meta.date} onChange={v=>updateMeta('date',v)} type="date"/>
      </div>
    </section>
    <section className="panel progress-panel"><div className="progress-upper"><div><h2>Commissioning progress</h2><p>{completed} of {total} checkpoints reviewed</p></div><div className="progress-number">{progress}<span>%</span></div></div><div className="progress-track"><div style={{width:`${progress}%`}}/></div><div className="progress-footer"><span><i className="legend pass"/> Passed: {counts.pass}</span><span><i className="legend fail"/> Failed: {counts.fail}</span><span><i className="legend na"/> N/A: {counts.na}</span><span><i className="legend pending"/> Pending: {counts.pending}</span></div></section>
    {view==='checklist'?<>
    <div className="checklist-heading"><div><h2>Inspection checklist</h2><p>Mark each checkpoint and add supporting remarks.</p></div><button className="text-button" onClick={allExpanded}>Expand all sections <ChevronDown size={15}/></button></div>
    <div className="toolbar"><div className="search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search checkpoints..."/></div><div className="filters">{(['all','pending','pass','fail','na'] as const).map(s=><button key={s} className={filter===s?'selected':''} onClick={()=>{setFilter(s);allExpanded()}}>{s==='all'?'All':statusLabels[s]}</button>)}</div></div>
    <div className="groups">{sections.map((g,sectionIndex)=>{
      const sectionDone=g.items.filter((_,i)=>(entries[`${g.id}-${i}`]?.status||'pending')!=='pending').length;
      const matches=g.items.map((item,i)=>({item,i})).filter(({item,i})=>(!search||item.toLowerCase().includes(search.toLowerCase())||g.title.toLowerCase().includes(search.toLowerCase()))&&(filter==='all'||(entries[`${g.id}-${i}`]?.status||'pending')===filter));
      if(!matches.length)return null;
      const isOpen=!!expanded[g.id]||!!search||filter!=='all';
      return <section className="group" key={g.id}><button className="group-toggle" onClick={()=>setExpanded(prev=>({...prev,[g.id]:!isOpen}))}><div className="group-number">{String(sectionIndex+1).padStart(2,'0')}</div><div className="group-title"><h3>{g.title}</h3><p>{g.subtitle}</p></div><div className="group-count">{sectionDone}/{g.items.length} reviewed</div><ChevronDown size={18} className={`chevron ${isOpen?'open':''}`}/></button>
      {isOpen&&<div className="group-body"><div className="item-labels"><span>CHECKPOINT</span><span>STATUS</span></div>{matches.map(({item,i})=>{const key=`${g.id}-${i}`;const itemState=entries[key]||{status:'pending',remarks:''};return <div className="check-row" key={key}><div className="check-content"><span className="item-id">{String(sectionIndex+1).padStart(2,'0')}.{String(i+1).padStart(2,'0')}</span><div><div className="check-text">{item}</div><input className="remarks" value={itemState.remarks} onChange={e=>updateEntry(key,{remarks:e.target.value})} placeholder="Add engineer remarks or observation (optional)" aria-label={`Remarks for ${item}`}/></div></div><div className="status-buttons" aria-label={`Result for ${item}`}>{(['pass','fail','na','pending'] as const).map(s=><button key={s} title={statusLabels[s]} onClick={()=>updateEntry(key,{status:s})} className={`status-option ${s} ${itemState.status===s?'chosen':''}`}>{s==='pass'?<Check size={14}/>:s==='fail'?<XCircle size={14}/>:null}{statusLabels[s]}</button>)}</div></div>})}</div>}</section>;
    })}</div>
    <section className="panel notes-panel"><h2>Additional commissioning notes</h2><p>Include observations, pending actions, references or handover comments.</p><textarea rows={4} value={meta.notes} onChange={e=>updateMeta('notes',e.target.value)} placeholder="Add overall commissioning notes here..."/></section>
    </>:<section className="panel overview-panel"><h2>Commissioning overview</h2><p>Section-by-section readiness for the active site.</p>{sections.map(g=>{const c={pass:0,fail:0,na:0,pending:0};g.items.forEach((_,i)=>c[entries[`${g.id}-${i}`]?.status||'pending']++);return <div className="overview-row" key={g.id}><div><strong>{g.title}</strong><span>{g.items.length-c.pending} of {g.items.length} reviewed</span></div><div className="mini-track"><div style={{width:`${(g.items.length-c.pending)/g.items.length*100}%`}}/></div><span className="mini-count">{c.pass} pass · {c.fail} fail</span></div>})}<button className="btn btn-outline" onClick={()=>setView('checklist')}>Back to checklist</button></section>}
    <div className="bottom-actions"><div className="bottom-left"><ShieldCheck size={19}/><div><strong>Your work is saved automatically</strong><span>Saved in this browser only. Export a backup when switching devices.</span></div></div><div className="action-buttons"><label className="btn btn-ghost import-btn">Import JSON<input type="file" accept=".json,application/json" onChange={importJson}/></label><button className="btn btn-outline" onClick={exportJson}><HardDriveDownload size={16}/> Backup JSON</button><button className="btn btn-primary" onClick={()=>downloadReport(meta,entries)}><ArrowDownToLine size={17}/> Download PDF</button></div></div>
    <div className="footer-tools"><button onClick={()=>setConfirmReset(true)}><RotateCcw size={14}/> Start new checklist</button><span>© IOTIQ · EMS Commissioning Portal v1.0</span></div>
   </div>
  </main>
  {notice&&<div className="toast"><Info size={16}/>{notice}</div>}
  {confirmReset&&<div className="modal-backdrop" onClick={()=>setConfirmReset(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="warning-icon"><AlertTriangle size={23}/></div><h2>Start a new checklist?</h2><p>This will clear your locally saved project details and all checkpoint results. Download a PDF or JSON backup first if you need to keep this record.</p><div className="modal-actions"><button className="btn btn-outline" onClick={()=>setConfirmReset(false)}>Cancel</button><button className="btn btn-danger" onClick={reset}>Clear checklist</button></div></div></div>}
 </div>;
}
function Field({label,value,onChange,placeholder,type='text'}:{label:string;value:string;onChange:(v:string)=>void;placeholder?:string;type?:string}){return <div className="field"><label>{label}</label><input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} type={type}/></div>}
function Stat({label,count,icon,accent}:{label:string;count:number;icon:React.ReactNode;accent:string}){return <div className="stat-card"><div><span>{label}</span><strong>{count}</strong></div><div className={`stat-icon ${accent}`}>{icon}</div></div>}
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
