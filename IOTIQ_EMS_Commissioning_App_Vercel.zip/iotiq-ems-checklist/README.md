# IOTIQ EMS Commissioning Checklist

Responsive, Vercel-ready engineering application to record energy meter commissioning results and generate PDF reports.

## Features
- 55 checkpoints across seven stages: compatibility, wiring, communication, data acquisition, EMS integration, reliability and handover
- Engineer/project/site/customer/controller details
- Per-checkpoint Pass, Fail, N/A and Pending status plus engineer remarks
- Search and status filters, progress tracking and overview
- Download full multi-page PDF commissioning report
- Automatically save the active checklist to browser localStorage
- Export/import JSON for backup or transfer
- Mobile-friendly interface

## Run locally

Requires Node.js 20 or later.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal, normally `http://localhost:5173`.

## Deploy on Vercel

1. Upload this folder to a GitHub repository, or import the project through Vercel.
2. In Vercel, choose **Add New > Project**, import the repository.
3. Framework preset should be **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. Deploy. No environment variables are required for this standalone version.

Alternatively install Vercel CLI and run `vercel` from this folder.

## Important data note

**This standalone version has no online authentication or shared database.** Data is saved in the current browser only. Engineers must use **Backup JSON** or **Download PDF** to retain the records when changing devices or clearing browser data. To support engineer logins, centralised records, audit trails and multi-device sync, integrate a backend such as Supabase before production deployment.

## Site safety

This app is documentation and checklist software. Installation and verification of mains voltage, CT/PT connections, grounding and electrical safety must be completed by authorized electrical personnel following the manufacturer's installation instructions.
